﻿Wypakuj cały plik "WPP Hellion_X.XX.rar" do wybranego przez siebie folderu

Utwórz skrót od pliku "main.exe" nastepnie wklej go gdze zechcesz



GOTOWE

Do otwierania/używania programu używaj stworzonego przez siebie skrótu












Licencja programu jest zawarta w pliku "Co nowego - Licencja.txt".